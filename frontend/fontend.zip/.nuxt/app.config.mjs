
import { defuFn } from 'D:/Andrei/projects/todolist/frontend/todolist/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default defuFn(inlineConfig)
